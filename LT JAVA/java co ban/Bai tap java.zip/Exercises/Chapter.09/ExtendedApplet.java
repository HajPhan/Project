import java.applet.*;
import java.awt.*;
import java.util.*;
public class ExtendedApplet extends Applet {
 String text;
 int x = 30;
 int y = 120;
 public void init() {
  try {
    text=System.getProperty("user.name");
  }catch(Exception ex){
    text=ex.toString();
  }
 }
 public void paint(Graphics g) {
  g.setFont(new Font("TimesRoman",Font.BOLD,12));
  g.drawString(text,x,y);
 }
}
