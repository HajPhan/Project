import java.awt.*;
import java.awt.event.*;
import java.applet.*;


public class ShapeApplet extends Applet{
    int shape;    
    Button button;   
    public void init()    {    
      shape = 0;
      button = new Button("Next Shape");        
      button.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
	        shape++;
        	if (shape == 6)            
	        shape = 0;        
        	repaint();
       }
      });

      add(button);    
    }

    public void paint(Graphics g)    {
        int x[] = {35, 150, 60, 140, 60, 150, 35};
        int y[] = {50, 80, 110, 140, 170, 200, 230};        
        int numPts = 7;

        switch(shape) {            
            case 0:
                g.drawLine(35, 50, 160, 230);                
                break;
            case 1:
                g.drawRect(35, 50, 125, 180);
                break;            
            case 2:
                g.drawRoundRect(35, 50, 125, 180, 15, 15);   
                break;
            case 3:             
                g.drawOval(35, 50, 125, 180);
                break;            
            case 4:
                g.drawArc(35, 50, 125, 180, 90, 180);  
                break;
            case 5:               
                g.drawPolygon(x, y, numPts);
                break;   
     }
    }
}