import java.applet.*;
import java.awt.*;

public class ReadImageApplet extends Applet{
      Image img;

      public void init(){
         img=getImage(getDocumentBase(),"java.gif");
      }      

      public void paint(Graphics g){
          g.drawImage(img,0,0,this);
      }
}