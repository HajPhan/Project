import java.awt.*;
import java.applet.*;

public class BallFlying 
                  extends Applet implements Runnable {

   Thread animThread;
   int ballX = 0; 
   int ballY =50;
   int dx=1;
   int dy=1;

   public void start() {
     if (animThread == null) {
        animThread = new Thread(this);
        animThread.start();
     }
   }

   public void stop() {
     animThread.stop();
     animThread = null;
   }

   public void run() {
     while (true) {
        moveBall(); 
        delay(50); 
     }
   }

   private void delay(int miliSeconds) {
        try {
          Thread.sleep(miliSeconds);
        } catch (Exception e) {
            System.out.println("Sleep error !");
        }
   }

   private void moveBall() {

      ballX+=dx;
      ballY+=dy;

      if (ballY > getSize().height-30) {
         dy=-dy;     
      }

      if (ballX > getSize().width-30)| {
         dx=-dx;     
      }

      if (ballY < 0) {
         dy=-dy;     
      }

      if (ballX <0) {
         dx=-dx;     
      }

     
     repaint();
   }

   public void paint(Graphics g) {
     g.setXORMode(getBackground());
     g.fillOval(ballX,ballY, 30, 30);
   }
}
