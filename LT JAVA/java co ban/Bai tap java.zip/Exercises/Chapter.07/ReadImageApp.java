import java.awt.*;
import java.awt.event.*;

public class ReadImageApp extends Frame{
      Image img;
      public ReadImageApp(String title){
           super(title);
           img=getToolkit().getImage("java.gif");
      }      

      public static void main(String args[]){
         ReadImageApp myWindow = 
                 new ReadImageApp("Image Application");
         myWindow.addWindowListener(new WindowAdapter(){
 	         public void windowClosing(WindowEvent event){
		    	         System.exit(0);
                 }
              });

          myWindow.setSize(new Dimension(200, 200));
          myWindow.show();         
     }

      public void paint(Graphics g){
          g.drawImage(img,0,0,this);
      }
}