import java.awt.*;
import java.awt.event.*;
import java.applet.*;


public class PolygonApplet extends Applet{

    public void paint(Graphics g)    {
        int x[] = {35, 150, 60, 140, 60, 150, 35};
        int y[] = {50, 80, 110, 140, 170, 200, 230};        
        int numPts = 7;
        g.fillPolygon(x, y, numPts);
    }

}