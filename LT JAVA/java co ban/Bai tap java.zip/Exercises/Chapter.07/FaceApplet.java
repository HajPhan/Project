import java.awt.*;
import java.applet.*;

public class FaceApplet extends Applet{

    public void paint(Graphics g)    {
        g.setColor(Color.yellow);
        g.fillOval(50,50,50,50);
        g.setColor(Color.black);
        g.fillOval(60,65,10,10);
        g.fillOval(80,65,10,10);
        g.fillOval(70,76,10,10);
        g.drawArc(62,70,25,25,-30,-120);

    }

}