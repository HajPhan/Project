import java.awt.*;
import java.applet.*;

public class RectOvalApplet extends Applet{
    public void paint(Graphics g)    {
       g.drawOval(10,10,100,100);
       g.fillRect(30,30,60,60);
    }
}