import java.awt.*;
import java.applet.*;

public class RectangleApplet extends Applet{
    public void paint(Graphics g)    {
       g.drawRect(75,50,100,50);
    }
}