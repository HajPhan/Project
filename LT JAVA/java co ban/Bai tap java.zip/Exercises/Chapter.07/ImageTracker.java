import java.applet.*;
import java.awt.*;

public class ImageTracker extends Applet{ 

      MediaTracker myTracker;

      Image image;

      public void     init() { 
           myTracker=new MediaTracker(this);
           image=getImage(getDocumentBase(),"java.gif");
           myTracker.addImage(image,0);
      }

      public void paint(Graphics g){
         if (myTracker.checkID(0)) {
            g.drawImage(image,0,15,this);
         }
         else {
            g.drawString("Please wait ...",10,10);
         } 
      }
}


