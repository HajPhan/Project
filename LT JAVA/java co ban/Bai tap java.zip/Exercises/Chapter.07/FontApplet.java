import java.applet.*;
import java.awt.*;

public class FontApplet extends Applet{
  public void paint(Graphics g){

     String fontList[];
     fontList = getToolkit().getFontList();

     int i;
     int startY=15;
     for (i=0; i < fontList.length; i++){
         g.setFont(new Font(fontList[i], Font.PLAIN, 12));
         g.drawString("This is the "+fontList[i]+" font.", 5,startY);

         startY += 15;
         g.setFont(new Font(fontList[i], Font.BOLD, 12));
         g.drawString("This is the bold "+fontList[i]+" font.", 5, startY);
         startY += 15;

         g.setFont(new Font(fontList[i], Font.ITALIC, 12));
         g.drawString("This is the italic "+fontList[i]+" font.", 5, startY);
         startY += 20;
     }
  }
}
