// Fig. 10.17: MyList2.java
// Copying items from one List to another.

import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import java.util.*;

public class MyList  implements ActionListener {
   private List colorList, copyList;
   private Button copy;
   private String colorNames[] =
      { "Black", "Blue", "Cyan", "Dark Gray", "Gray", "Green",
        "Light Gray", "Magenta", "Orange", "Pink", "Red",
        "White", "Yellow" };
   public static void main (String args []) {
	Frame f = new Frame("My List");
	MyList m = new MyList();
	f.add("Center", m);
	f.show();	
	m.init();	
  }
   public void init()
   {
      // create a list with 5 items visible
      // allow multiple selections
      colorList = new List( 5, true );

      // add items to the list
      for ( int i = 0; i < colorNames.length; i++ )
         colorList.add( colorNames[ i ] );

      add( colorList );

      // create copy button
      copy = new Button( "Copy >>>" );
      copy.addActionListener( this );
      add( copy );

      // create a list with 5 items visible
      // do not allow multiple selections
      copyList = new List( 5, false );
      add( copyList );
   }

   public void actionPerformed( ActionEvent e )
   {
      String colors[];

      // get the selected states
      colors = colorList.getSelectedItems();

      // copy them to copyList
      for ( int i = 0; i < colors.length; i++ )
         copyList.add( colors[ i ] );
   }
}
