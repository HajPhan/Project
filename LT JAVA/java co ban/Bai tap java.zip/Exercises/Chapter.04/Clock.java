import java.applet.Applet;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
//
public class Clock extends Applet implements Runnable{
    Thread thisThread;

    Color faceColor, borderColor, minuteColor, hourColor, 
						secondColor;

    public void init(){
         //read in the colors for each of the hands and for the face/border
         faceColor = readColor (getParameter("faceCol"));
         borderColor = readColor (getParameter("borderCol"));
         minuteColor = readColor (getParameter("minuteCol"));
         hourColor = readColor(getParameter("hourCol"));
         secondColor = readColor(getParameter("secondCol"));
    }

    // This method creates a color based on a  string.
    // The string is assumed to be "red,green,blue"  where each
    // of the colors is represented by its integer equivalant.
    public Color readColor(String aColor) {
     if (aColor == null) { 
           return Color.black; 
      }
     
     int r;
     int g;
     int b;
     
      //break the string apart into each number
      StringTokenizer st = new StringTokenizer(aColor, ",");
     
     try {
         r = Integer.valueOf(st.nextToken()).intValue();
         g = Integer.valueOf(st.nextToken()).intValue();
         b = Integer.valueOf(st.nextToken()).intValue();          
         return new Color(r,g,b);
     }
     catch (Exception e) {
         System.out.println("An exception occured trying to conver a parameter           to a color:"+e);
         return Color.black;
     }
   }
 

    public void start(){
         thisThread = new Thread(this);
         thisThread.start();
    }

    public void run(){
         while(true){
              repaint();
              try{
                   thisThread.sleep(1000);
              }catch (Exception e){}
         }
    }

    public void update(Graphics g){
         paint(g);
    }

    public void paint(Graphics g){
         //fill clock face
         g.setColor(faceColor);
         g.fillOval(0,0,100,100);
         g.setColor(borderColor);
         g.drawOval(0,0,100,100);
              
         //get the current time
         Calendar d = Calendar.getInstance();
         //draw the minute hand
         g.setColor(minuteColor);     
         double angle = (((double)(90 - d.get(Calendar.MINUTE)))/60)*2 * Math.PI;     
         g.drawLine(50,50,50+(int)(Math.sin(angle)*50),50 + (int)(Math.cos(angle)*50));
         //draw the hour hand
         g.setColor(hourColor);
         angle = ((((double)18 - d.get(Calendar.HOUR_OF_DAY)+(double)d.get(Calendar.MINUTE)/60))/12)*2* Math.PI;
         g.drawLine(50,50,50+(int)(Math.sin(angle)*40),50 +(int)(Math.cos(angle)*40));
         //draw the second hand
         g.setColor(secondColor);
         angle = (((double)(90 - d.get(Calendar.SECOND)))/60)*2 * Math.PI;          
         g.drawLine(50,50,50+(int)(Math.sin(angle)*50),50 +(int)(Math.cos(angle)*50));
    }
	static boolean inApplet =true;
	public static void main(String args[]){
         /*set a boolean flag to show if you are in an applet or not */
         inApplet=false;

         /*Create a Frame to place our application in. */
         /*You can change the string value to show your desired label*/
         /*for the frame */
         Frame myFrame = new Frame ("Clock as an Application");
	 myFrame.addWindowListener (new WindowAdapter(){
	     public void windowClosing (WindowEvent event){
		System.exit(0);
	     }
	 });
         /*Create a clock instance. */
         Clock myApp = new Clock();         /*Add the current application to the Frame */
         myFrame.add ("Center",myApp);


    /*Resize the Frame to the desired size, and make it visible */
    /*Resize the Frame to the desired size, and make it visible */
    if (args.length>=2)
/*resize the Frame based on command line inputs */
          myFrame.setSize(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
    else
         myFrame.setSize(100,130);
    myFrame.show();

         /*Run the methods the browser normally would */
         myApp.init();
         myApp.start();

	}
public String getParameter (String name){
    String ST;
    if (inApplet)
         return super.getParameter(name);
    //If you are not in an applet you default all of the values.
    if (name == "hourCol")
         return "255,00,00" ;
    if (name == "minuteCol")
         return "00,255,00";
    if (name == "secondCol")
         return "00,00,255";
    if (name == "borderCol")
         return "255,255,255";
    if (name == "faceCol")
         return "125,125,125"; 
    return null;

}

}
