public class Foo {
    int fo;
    public void init() {
	System.out.println("Init Method");
    }	
    public static void main(String args[]){
         fo = 50; 
	 System.out.println("Init - Method");	
    }
}

