import java.applet.Applet;
import java.awt.*;

public class Converti extends Applet{
   String m_unit;
   double m_value = 0 ;
   public void init(){
    m_unit = getParameter("MEASURE_UNIT");
    m_value = Double.parseDouble(getParameter("MVALUE"));
   }
	
   public void paint(Graphics g){
	String temp;
	temp = "So da cho: " + m_value + " " + m_unit;
    g.setFont(new Font("VNI-Centur",Font.BOLD,12));
    g.drawString(temp, 5,25);
	temp = "Ket qua chuyen doi la : ";
    g.drawString(temp,5,40);
     if (m_unit == "CM") 
	temp = m_value / 2.54 + " INCH";	
    else
	temp = m_value * 2.54 + " CM";
    g.drawString(temp, 5,55);
   }
}
