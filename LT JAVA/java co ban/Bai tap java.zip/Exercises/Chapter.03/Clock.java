import java.awt.*;
import java.applet.*;
import java.util.*;
import java.text.*;

/*
 * class for applet/application
 */
public class Clock extends Applet implements Runnable {

/*
 * the instance of Thread for checking the time periodically
 */
Thread thread = null;
SimpleDateFormat formatter;
Date currentDate;

/*
 * saved values used to draw only when things have changed
 */
int lastxs=0;
int lastys=0;
int lastxm=0;
int lastym=0;
int lastxh=0;
int lastyh=0;

/**
  * sets the background color to light gray
  */
public void init(){
        this.setBackground(Color.lightGray);
}

/**
 * draws the clock face
 * @param g - destination graphics object
 */
public void paint (Graphics g) {

 int xh, yh, xm, ym, xs, ys, s=0,m=10, h=10, xcenter, ycenter;
String Today;
    currentDate = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("s",Locale.getDefault());
try{
        s=Integer.parseInt(formatter.format(currentDate));
    }catch(NumberFormatException n){
        s=0;
    }

    formatter.applyPattern("m");
    try{
        m=Integer.parseInt(formatter.format(currentDate));
    }catch(NumberFormatException n){
        m=10;
    }

    formatter.applyPattern("h");
    try{
        h=Integer.parseInt(formatter.format(currentDate));
    }catch(NumberFormatException n){
        h=10;
    }

       xcenter=100;
       ycenter=100;

       xs = (int)(Math.cos(s * 3.14f/30 - 3.14f/2) * 45 + xcenter);
	ys = (int)(Math.sin(s * 3.14f/30 - 3.14f/2) * 45 + ycenter);
	xm = (int)(Math.cos(m * 3.14f/30 - 3.14f/2) * 40 + xcenter);
	ym = (int)(Math.sin(m * 3.14f/30 - 3.14f/2) * 40 + ycenter);
	xh = (int)(Math.cos((h*30 + m/2) * 3.14f/180 - 3.14f/2) * 30+ xcenter);
       yh = (int)(Math.sin((h*30 + m/2) * 3.14f/180 - 3.14f/2) * 30+ ycenter);

// Draw the circle and numbers
       g.setFont(new Font("VNI-Centur", Font.PLAIN, 14));
       g.setColor(Color.blue);
       g.drawOval (xcenter-50, ycenter-50, 100, 100);
       g.setColor(Color.darkGray);
       g.drawString("9",xcenter-45,ycenter+3);
       g.drawString("3",xcenter+40,ycenter+3);
       g.drawString("12",xcenter-5,ycenter-37);
       g.drawString("6",xcenter-3,ycenter+45);

// Erase if necessary, and redraw
       g.setColor(Color.lightGray);
       if (xs != lastxs || ys != lastys) {
              g.drawLine(xcenter, ycenter, lastxs, lastys);
       }
       if (xm != lastxm || ym != lastym) {
              g.drawLine(xcenter, ycenter-1, lastxm, lastym);
              g.drawLine(xcenter-1, ycenter, lastxm, lastym);
       }
       if (xh != lastxh || yh != lastyh) {
              g.drawLine(xcenter, ycenter-1, lastxh, lastyh);
              g.drawLine(xcenter-1, ycenter, lastxh, lastyh);
       }

       g.setColor(Color.darkGray);
       g.drawLine(xcenter, ycenter, xs, ys);
       g.setColor(Color.red);
       g.drawLine(xcenter, ycenter-1, xm, ym);
       g.drawLine(xcenter-1, ycenter, xm, ym);
       g.drawLine(xcenter, ycenter-1, xh, yh);
       g.drawLine(xcenter-1, ycenter, xh, yh);
       lastxs=xs; lastys=ys;
       lastxm=xm; lastym=ym;
       lastxh=xh; lastyh=yh;
}

/*
 * called when the applet is started
 * create a new instance of Thread and start it
 */
public void start() {

       if(thread == null) {
              thread = new Thread(this);
              thread.start();
       }
}

/*
 * called when the applet is stopped
 * stops the thread
 */
public void stop() {

       thread = null;
}

/*
 * the thread itself
 * sleeps for 100ms and forces a repaint
 */
public void run() {

       while (thread != null) {
              try {
                     Thread.sleep(100);
              } catch (InterruptedException e) { }
              repaint();
       }
       thread = null;
}

/**
 * override the default update method to avoid flickering
 * caused by unnecessary erasing of the applet panel
 * @param g - destination graphics object
 */
public void update(Graphics g) {
       paint(g);
}

/**
 * application entry point
 * not used when run as an applet
 * create a new window frame and add the applet inside
 * @param args[] - command-line arguments
 */
public static void main (String args[]) {

       Frame f = new Frame ("Clock");
       Clock clock = new Clock ();
       f.setSize (210, 230);
       f.add ("Center", clock);
       f.show ();
       clock.init ();
       clock.start ();
}
}

