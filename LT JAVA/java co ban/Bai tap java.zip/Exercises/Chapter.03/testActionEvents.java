import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class testActionEvents extends Applet
{
    public void init()
    {	setFont(new Font("VNI Couri",Font.ITALIC + Font.BOLD,12));
        super.init();	
        setLayout(null);
        btnHello = new Button("Say Hello");
        btnHello.setBounds(36,12,108,43);
        add(btnHello);
        Action btnAction = new Action();
        btnHello.addActionListener(btnAction);
        txtField1 = new TextField();
        txtField1.setBounds(36,96,144,31);
        add(txtField1);

    }
    /* Declare Components */
    Button btnHello;
    TextField txtField1;

    class Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {  
            Object object1 = event.getSource();
            if (object1 == btnHello)
                btnHelloAction(event);
        }
    }

    void btnHelloAction(ActionEvent e)
    {	txtField1.setFont(new Font(".VNArial",Font.BOLD,12));
        txtField1.setText("Hello Java");
    }
}