import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.Math;
/* ca�n ca�i �a�t the�m giao tie�p ActionListener �e� nha�n bie�t ca�c thao ta�c nha�p d�� lie�u va�o ca�c o� va�n ba�n */
public class Number3 extends Applet implements ActionListener 
{
    TextField textField1;
    TextField textField2;
    TextField textField3;

    public void init()
    {  setFont(new Font("VNI-Centur", Font.BOLD, 12));
        textField1 = new TextField(5);
        textField2 = new TextField(5);
        textField3 = new TextField(5);

        add(textField1);
        add(textField2);
	 add(textField3);

        textField1.setText("0");
        textField2.setText("0");
	 textField3.setText("0");
			
	textField1.addActionListener(this);
	textField2.addActionListener(this);
	textField3.addActionListener(this);
	 }

    public void paint(Graphics g)
	{
        int value1;
        int value2;
	int value3;
        long sum;

        g.drawString("Type a number in each box.", 40, 50);
        g.drawString("The result of the expression", 40, 75);
	g.drawString("(Number1 * 3) + (Number2 - Number3) is", 40, 100);

        String s = textField1.getText();
        value1 = Integer.parseInt(s);
        s = textField2.getText();
        value2 = Integer.parseInt(s);
        s = textField3.getText();
        value3 = Integer.parseInt(s);
        sum = (value1 * 3) + (value2 - value3);
        s = String.valueOf(sum);
        g.drawString(s, 80, 125);
    }

    public void actionPerformed(ActionEvent event)
    {
        repaint();       
    }
}
