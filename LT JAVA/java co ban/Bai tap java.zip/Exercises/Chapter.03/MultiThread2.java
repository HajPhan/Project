import java.applet.Applet;
import java.awt.*;

/**
 * class LineColors holds 24 color values
 */
class LineColors {

/**
 * color[] array holds the colors to be used
 */
Color color[];

/**
 * class constructor
 * initializes the color array by using an arbitrary algorithm
 */
public LineColors () {
       color = new Color[24];
       int i, rgb;

       rgb = 0xff;
       for (i=0; i<24; i+=1) {
              color[i] = new Color (rgb);
              rgb <<= 1;
              if ((rgb & 0x1000000) != 0) {
                     rgb |= 1;
                     rgb &= 0xffffff;
              }
       }
}
}

/**
 * class describing one line segment
 */
class Segment {

/*
 * x1, y1 - starting coordinates for this segment
 * x2, y2 - ending coordinates for this segment
 * dx1,...dy2 - velocities for the endpoints
 * whichcolor - the current index into color array
 * width, height - width and height of bounding panel
 * LC - instance of LineColors class
 */
double x1, y1, x2, y2;
double dx1, dy1, dx2, dy2;
int whichcolor, width, height;
LineColors LC;

/**
 * class constructor
 * initialize endpoints and velocities to random values
 * @param w - width of bounding panel
 * @param h - height of bounding panel
 * @param c - starting color index
 * @param lc - instance of LineColors class
 */
public Segment (int w, int h, int c, LineColors lc) {

       whichcolor = c;
       width = w;
       height = h;
       LC = lc;
       x1 = (double) w * Math.random ();
       y1 = (double) h * Math.random ();
       x2 = (double) w * Math.random ();
       y2 = (double) h * Math.random ();

       dx1 = 5 - 10 * Math.random ();
       dy1 = 5 - 10 * Math.random ();
       dx2 = 5 - 10 * Math.random ();
       dy2 = 5 - 10 * Math.random ();
}

/*
 * increment color index
 * calculate the next endpoint position for this segment
 */
void compute () {

       whichcolor += 1;
       whichcolor %= 24;

       x1 += dx1;
       y1 += dy1;
       x2 += dx2;
       y2 += dy2;

       if (x1 < 0 || x1 > width) dx1 = -dx1;
       if (y1 < 0 || y1 > height) dy1 = -dy1;
       if (x2 < 0 || x2 > width) dx2 = -dx2;
       if (y2 < 0 || y2 > height) dy2 = -dy2;
}

/**
 * draw the line segment using the current color
 * @param g - destination graphics object
 */
void paint (Graphics g) {

       g.setColor (LC.color [whichcolor]);
       g.drawLine ((int) x1, (int) y1, (int) x2, (int) y2);
}
}

/**
 * The applet/application proper
 */
class Lines extends Panel implements Runnable {

/*
 * width, height - width and height of bounding panel
 * Nlines - number of line segments to be displayed
 * lines - array of instances of Segment class
 * LC - instance of LineColors class
 */

int width, height;
final int NLines = 4;
Segment lines[] = new Segment[NLines];
LineColors LC = new LineColors ();

/*
 * instance of thread for this line
 */
Thread thread;

/**
 * init is called when the applet is loaded
 * save the width and height
 * create instances of Segment class
 */
public void init (int inPriority) {

       width = 200;
       height = 200;

       thread = new Thread (this);
       thread.start ();
       thread.setPriority(inPriority);

       int i;
       for (i=0; i<NLines; i+=1)
              lines[i] = new Segment (width, height, (2*i) % 24, LC);
}

/**
 * recompute the next endpoint coordinates for each line
 * invoke paint() method for each line
 * @param g - destination graphics object
 */
public void paint (Graphics g)
{

       int i;
       g.setColor (Color.black);
       g.drawRect (0, 0, width-1, height-1);
       for (i=0; i<NLines; i+=1) {
              lines[i].compute ();
              lines[i].paint (g);
       }
}

/*
 * the thread proper
 * calls paint() every 50ms
 */
public void run()
{
       Graphics g = getGraphics();
       int iterCount = 0;
       while (true) {
              paint(g);
              try {
                     iterCount += 1;
                     if (iterCount == 5) {
                            Thread.sleep(100);
                            iterCount = 0;
                     }
              }
              catch (InterruptedException e) {
                     System.out.println("Caught exception...");
}
       }
}
}

/*
 * the applet/application proper
 * creates two instances of Lines and starts them
 * as separate threads
 */
public class MultiThread2 extends Applet {

/*
 * the instances of Lines
 */
Lines lines[];

/*
 * the number of threads to be run
 */
public final static int NumThreads = 5;

/*
 * the priority of the first thread
 */
public final static int StartingPriority = Thread.NORM_PRIORITY;

/*
 * called when the applet is loaded
 * creates several instances of Lines and adds them to the
 * applet panel
 * sets the priority of each thread to 1 less than the previous
 * one
 */
public void init () {

       setLayout (new GridLayout (MultiThread2.NumThreads, 1, 0, 0));
       lines = new Lines[MultiThread2.NumThreads];
       for (int i = 0; i< MultiThread2.NumThreads; i++) {
              lines[i] = new Lines ();
              add (lines[i]);
              lines[i].setSize (200, 200/MultiThread2.NumThreads);
              lines[i].init (StartingPriority-i);
       }
}

/**
 * application entry point, unused when run as an applet
 * create window frame and add applet inside
 * @param args[] - command-line arguments
 */
public static void main (String args[]) {

       Frame f = new Frame ("Colored lines");
       f.setLayout (new GridLayout (MultiThread2.NumThreads, 1, 0, 0));

       f.setSize (200, 200);
       Lines lines[] = new Lines[MultiThread2.NumThreads];

       for (int i = 0; i< MultiThread2.NumThreads; i++) {
              lines[i] = new Lines ();
              f.add (lines[i]);
       }

       f.show ();

       for (int i = 0; i< MultiThread2.NumThreads; i++) {
              lines[i].init (StartingPriority-i);
       }
}
}
