import java.awt.*;
import java.awt.event.*;
import FontChoiceApplet;

public class FontChoiceApp extends Frame {
  FontChoiceApplet a = new FontChoiceApplet();

  public FontChoiceApp(String appTitle){
     super(appTitle);
     a.init();
     a.start();     

     setLayout(new BorderLayout());
     add(a,BorderLayout.CENTER);
  }

  public static void main(String args[]){
    FontChoiceApp app= new FontChoiceApp("Font Choice Application");

    app.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    app.setSize(250,250);    
    app.setVisible(true);
  }
}

