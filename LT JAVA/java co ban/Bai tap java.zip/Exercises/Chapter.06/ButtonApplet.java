import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonApplet extends Applet{  

   public String msg="";

   public void init()     {
          Button b = new Button("Hello");
          b.addActionListener(new ButtonListener(this));
          add(b);
   }

   public void paint(Graphics g){
       g.drawString(msg,60,60);
   }
}

class ButtonListener implements ActionListener{       
     Component component;     

     public ButtonListener(Component component){ 
         this.component = component;
     } 

     public void actionPerformed(ActionEvent evt)  {       
          ((ButtonApplet)component).msg="Xin chao";  
          component.repaint(); 
    }
}
