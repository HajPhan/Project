import java.awt.*;
import java.awt.image.*;

public class ImageViewer extends Canvas{
   Image image;
   public ImageViewer(Image image){
       this.image=image;
   }
   public void paint(Graphics g){
       int h=image.getHeight(this);
       int w=image.getWidth(this);
       g.drawImage(image,0,0,w,h,this);      
   }
}
