import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class FontChoiceApplet extends Applet{  

  List fontListBox = new List();
  Label label1 = new Label();
  Label label3 = new Label();
  Label label4 = new Label();
  Label label5 = new Label();
  Label sampleLabel = new Label();

  TextField fontSizeText = new TextField();
  Checkbox boldStyle = new Checkbox();
  Checkbox italicStyle = new Checkbox();
  Choice colorChoice = new Choice();

 public void init()     {

  label1.setBounds(new Rectangle(2, 4, 83, 19));
  label1.setText("Font name");
  setLayout(null);
  fontListBox.setBounds(new Rectangle(3, 23, 104, 116));
  
  sampleLabel.setBackground(Color.yellow);
  sampleLabel.setFont(new Font("TimesRoman", 1, 16));
  sampleLabel.setBounds(new Rectangle(71, 157, 167, 26));
  sampleLabel.setText("Sample Font");
  
  label3.setBounds(new Rectangle(124, 3, 34, 20));
  label3.setText("size");
  fontSizeText.setBounds(new Rectangle(123, 24, 142, 20));
  fontSizeText.setText("16");
  
  label4.setBounds(new Rectangle(124, 51, 35, 12));
  label4.setText("Style");
  
  boldStyle.setBounds(new Rectangle(125, 67, 57, 22));
  boldStyle.setLabel("Bold");
  boldStyle.setState(true);

  italicStyle.setBounds(new Rectangle(203, 70, 65, 17));
  italicStyle.setLabel("Italic");

  label5.setBounds(new Rectangle(121, 100, 116, 17));
  label5.setText("Background Color");
  colorChoice.setBounds(new Rectangle(120, 120, 152, 23));

  add(fontListBox, null);
  add(label1, null);
  add(sampleLabel, null);
  add(label3, null);
  add(fontSizeText, null);
  add(label4, null);
  add(boldStyle, null);
  add(italicStyle, null);
  add(colorChoice, null);
  add(label5, null);

  String fontList[]=getToolkit().getFontList();
  for (int i=0; i < fontList.length; i++){
      fontListBox.add(fontList[i]);
  }

  fontListBox.addActionListener( new ActionListener(){
          public void actionPerformed(ActionEvent evt) {
               String clickItem= evt.getActionCommand();
               sampleLabel.setText(clickItem);
               updateFontSample();                
         }
    });

  colorChoice.addItem("Red");
  colorChoice.addItem("Green");
  colorChoice.addItem("Blue");
  colorChoice.addItem("Yellow");

  colorChoice.select("Yellow");
  colorChoice.addItemListener(new ItemListener(){
    public void itemStateChanged(ItemEvent event){
               updateFontSample();                        
    }
   });

  boldStyle.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
               updateFontSample();                              
      }
    });

  italicStyle.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
               updateFontSample();                              
      }
    });

  fontSizeText.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
               updateFontSample();                              
      }
    });
 }


  public void updateFontSample(){
        String fontName=sampleLabel.getText();
        int style=Font.PLAIN;
        if (boldStyle.getState()) style=style+Font.BOLD;
        if (italicStyle.getState()) style=style+Font.ITALIC;
        int size=12;
        try{
            size=Integer.parseInt(fontSizeText.getText());
        } catch (NumberFormatException e){}

        int colorIdx=colorChoice.getSelectedIndex();
        Color bkgColor=Color.white;
        switch (colorIdx){
             case 0: bkgColor=Color.red;
                     break;
             case 1: bkgColor=Color.green;
                     break;
             case 2: bkgColor=Color.blue;
                     break;
             case 3: bkgColor=Color.yellow;
                     break;
        }

        sampleLabel.setFont(new Font(fontName,style,size)); 
        sampleLabel.setBackground(bkgColor);       
  }

}


