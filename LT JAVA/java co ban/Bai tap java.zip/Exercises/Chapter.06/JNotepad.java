import java.awt.*;
import java.awt.event.*;

public class JNotepad extends Frame {

  TextArea notepadText = new TextArea("Welcome to Java notepad");
  String fontName="SansSerif";
  int  fontStyle=Font.PLAIN;

  MenuBar mainMenuBar = new MenuBar();

  Menu fileBarItem = new Menu("File");
  MenuItem openItem = new MenuItem("Open");
  MenuItem saveItem = new MenuItem("Save");
  MenuItem ExitItem = new MenuItem("Exit");

  Menu editBarItem = new Menu("Edit");
  Menu editFontSub = new Menu("Font");
    MenuItem fontItem1 = new MenuItem("SansSerif");
    MenuItem fontItem2 = new MenuItem("Courier");
    MenuItem fontItem3 = new MenuItem("TimesRoman");

  Menu editColorSub = new Menu("Color");
    MenuItem colorBlueItem = new MenuItem("Blue");
    MenuItem colorRedItem = new MenuItem("Red");
    MenuItem colorBlackItem = new MenuItem("Black");
  Menu editStyleSub = new Menu("Style");
    CheckboxMenuItem styleBoldChecker = new CheckboxMenuItem("Bold");
    CheckboxMenuItem styleItalicChecker = new CheckboxMenuItem("Italic");


  public JNotepad(){ 
    setLayout(new BorderLayout());
    setTitle("Java Notepad");

    ExitItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
           System.exit(0);      }
    });


    fontItem1.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	 fontName=fontItem1.getLabel();
	 updateFont();
      }
    });

    fontItem2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	 fontName=fontItem2.getLabel();
	 updateFont();
      }
    });

    fontItem3.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	 fontName=fontItem3.getLabel();
	 updateFont();
      }
    });

    colorBlueItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
           notepadText.setForeground(Color.blue);
      }
    });

    colorRedItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
           notepadText.setForeground(Color.red);
      }
    });

    colorBlackItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
           notepadText.setForeground(Color.black);
      }
    });

    styleBoldChecker.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
         fontStyle=Font.PLAIN;
         if  (styleBoldChecker.getState()) 
                   fontStyle=fontStyle+Font.BOLD;
         
         if  (styleItalicChecker.getState())
                   fontStyle=fontStyle+Font.ITALIC;         
         updateFont();
       }
      });

    styleItalicChecker.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
         fontStyle=Font.PLAIN;
         if  (styleBoldChecker.getState()) 
                   fontStyle=fontStyle+Font.BOLD;
         
         if  (styleItalicChecker.getState())
                   fontStyle=fontStyle+Font.ITALIC;         
         updateFont();
      }
    });

    add(notepadText, BorderLayout.CENTER);
    mainMenuBar.add(fileBarItem);
    mainMenuBar.add(editBarItem);

    fileBarItem.add(openItem);
    fileBarItem.add(saveItem);
    fileBarItem.add(ExitItem);

    editBarItem.add(editFontSub);
    editBarItem.add(editColorSub);
    editBarItem.add(editStyleSub);

    editFontSub.add(fontItem1);
    editFontSub.add(fontItem2);
    editFontSub.add(fontItem3);

    editColorSub.add(colorBlueItem);
    editColorSub.add(colorRedItem);
    editColorSub.add(colorBlackItem);

    editStyleSub.add(styleBoldChecker);
    editStyleSub.add(styleItalicChecker);

    setMenuBar(mainMenuBar);
  }


  private void updateFont(){
     notepadText.setFont(new Font(fontName,fontStyle,12));
  }


  public static void main(String args[]){
    JNotepad app = new JNotepad();

    app.addWindowListener(new WindowAdapter() {

      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    app.setSize(300,300);    
    app.setVisible(true);
  }
}

