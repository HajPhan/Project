import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Button1Applet extends Applet{  

   public String msg="";

   public void init()     {
          Button b = new Button("Hello");
          b.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent evt)  {       
                 msg="Xin chao";  
                 repaint();
             }

          });          
          add(b);
   }

   public void paint(Graphics g){
       g.drawString(msg,60,60);
   }
}


