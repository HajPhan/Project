import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class InputApplet extends Applet{  

   TextField textField1 = new TextField();
   TextField textField2 = new TextField();
   Label label1 = new Label();

   public void init()     {

      textField1.setBounds(new Rectangle(22, 22, 144, 19));
      textField1.setText("Gary Samson");
      textField1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
                 repaint();
         }
       });

      textField2.setBounds(new Rectangle(24, 46, 142, 20));
      textField2.setText("29");
      textField2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
                 repaint();
         }
       });

      label1.setBounds(new Rectangle(26, 73, 147, 20));
      label1.setText("Type your name and age above");

      setLayout(null);
      add(textField1, null);
      add(textField2, null);
      add(label1, null);
   }

   public void paint(Graphics g){
       g.drawString(textField1.getText(),50,160);
       g.drawString(textField2.getText(),50,175);
   }
}


