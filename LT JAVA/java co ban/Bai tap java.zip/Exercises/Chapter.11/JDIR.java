import java.io.*;

public class JDIR {
  public static void main(String args[]){
      if (args.length !=1){
          System.out.println("usage: java JDIR <directory>");
          return;
      }

      String directory=args[0];
      File  curDir=new File(directory); 
      String[] dirs=curDir.list();
   
      for (int i=0; i<dirs.length; i++) {
         File f=new File(directory+dirs[i]);
         if (f.isDirectory()) {
	   System.out.println("<DIR>   "+dirs[i]);
	 } else{
	    System.out.println("        "+dirs[i]);
	 }		
       }
  }
}
