import java.io.*;
public class JTYPE {
  public static void main(String args[]){

        if (args.length !=1){
          System.out.println("usage: java JTYPE <Filename>");
          return;
        }

	try{
                String fileName=args[0];
		FileInputStream f=new 
                     FileInputStream(fileName);
		int ch=0;
		while ((ch=f.read())!= -1) {
			System.out.print((char)ch);
		}
		f.close();
	}
	catch (FileNotFoundException e){
		System.out.println("File not found !");		
	}	
	catch(IOException e){
		System.out.println("Can not read file !");
	}
  }
}
