import java.io.*;
public class JCOPY {
  public static void main(String args[]){

        if (args.length !=2){
          System.out.println("usage: java JCOPY <srcFile> <destFile>");
          return;
        }

	try{
                String srcFileName=args[0];
                String destFileName=args[1];
 
		FileInputStream src=new 
                     FileInputStream(srcFileName);
		FileOutputStream dest=new 
                     FileOutputStream(destFileName);

		int ch=0;

		while ((ch=src.read())!= -1) {
			dest.write((byte)ch);
		}
                System.out.println("One file copy !");
	}
	catch (FileNotFoundException e){
		System.out.println("File not found !");		
	}	
	catch(IOException e){
		System.out.println("Can not read file !");
	}
  }
}
