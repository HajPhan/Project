import java.io.*;
public class LineReader {
  public static void main(String args[]) throws Exception{
       if (args.length !=1){
          System.out.println("usage: java LineReader <TextFile>");
          return;
       }
       FileReader f=new FileReader(args[0]);
       LineNumberReader doc= new LineNumberReader(f);
       String s;
       while ((s=doc.readLine())!=null) {
		System.out.print(doc.getLineNumber()+" : ");
		System.out.println(s);
       }
  }
}