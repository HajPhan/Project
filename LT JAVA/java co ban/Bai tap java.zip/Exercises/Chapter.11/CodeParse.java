import java.io.*;

public class CodeParse {

 public static void main(String args[]) throws IOException {
  if (args.length !=1){
          System.out.println("usage: java CodeParse <SourceFile>");
          return;
  }

  FileReader f= new FileReader(args[0]);

  StreamTokenizer inStream = new StreamTokenizer(f);
  
  inStream.slashSlashComments(true);
  inStream.slashStarComments(true);

  boolean eof=false;
  do {
   int token=inStream.nextToken();
   
   switch(token){
   	case inStream.TT_WORD:        
                if (isKeyword(inStream.sval))
      		   System.out.println("Java key: "+inStream.sval);
    		break;
   	case inStream.TT_EOF:
                eof=true;
   }
  } while(!eof);

  System.out.println("Code parse completed");
 }

 private static boolean isKeyword(String keyword){
    String keyList[]={"abstract","boolean","break","byte","case"
		      ,"cast","catch","char","class","const","continue"
		      ,"default","do","double","else","extends","final"
                      ,"finally","float","for","future","generic","goto"
                      ,"if","implements","import","inner","instanceof","int"
                      ,"interface","long","native","new","null","operator"
                      ,"outer","package","private","protected","public"
		      ,"rest","return","short","static","super","switch"
                      ,"synchronized","this","throw","throws","transient"
                      ,"try","var","void","volatile","while"};

    for (int i=0; i<keyList.length;i++){
       if (keyList[i].equals(keyword)) return true;
    }
    return false;
 }
}
