import java.io.*;
public class SearchDirApp{

  public static void searchFolder(String root){
            File  curDir=new File(root); 
	    String[] dirs=curDir.list();
	    for (int i=0; i<dirs.length; i++) {
                String curFolder=root+dirs[i];
		File f=new File(curFolder);
		if (f.isDirectory()) {
                   System.out.println(curFolder);
                   searchFolder(curFolder+"/");
		}
	    }
  }

  public static void main(String args[]){
      searchFolder("C:/");
  }
}
