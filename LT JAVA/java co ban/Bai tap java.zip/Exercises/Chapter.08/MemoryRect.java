import java.applet.*;
import java.awt.*;
import java.awt.image.*;

public class MemoryRect extends Applet{
    
     Image img;

     final static int r=Color.red.getRGB();

     int[] pixels;
 
     public void init() {
        pixels=new int[16*16];

        for (int i=0; i<pixels.length; i++){
           pixels[i]=r;
        }

        MemoryImageSource producer=new 
                    MemoryImageSource(16,16,pixels,0,16);
        img=createImage(producer);
     }

     public void paint(Graphics g){         
        g.drawImage(img,10,10,this);
     }
}
