import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class ImageEffect extends Applet{  

  Image img;
  Label choiceLabel = new Label("Effect");
  Choice colorChoice = new Choice();
  
 public void init()     {
  img=getImage(getDocumentBase(),"Beans.gif");
  setLayout(null);

  choiceLabel.setBounds(new Rectangle(6, 5, 60, 17));
  colorChoice.setBounds(new Rectangle(8, 25, 120, 25));

  add(colorChoice, null);
  add(choiceLabel, null);

  colorChoice.addItem("Origin Image");
  colorChoice.addItem("Rotate Horizontal");
  colorChoice.addItem("Rotate Vertical");
  colorChoice.addItem("Zoom 50%");
  colorChoice.addItem("Zoom 200%");


  colorChoice.select("Origin Image");
  colorChoice.addItemListener(new ItemListener(){
    public void itemStateChanged(ItemEvent event){
         repaint();
    }
   });
 }
 
 public void paint(Graphics g){

      int h=img.getHeight(this);
      int w=img.getWidth(this);
      
      int effectIdx=colorChoice.getSelectedIndex();
      switch (effectIdx){
         case 0: g.drawImage(img,130,0,this);
                 break;
         case 1: g.drawImage(img,130,h,w+130,0,0,0,w,h,this);
                 break;
         case 2: g.drawImage(img,w+130,0,130,h,0,0,w,h,this);
                 break;
         case 3: g.drawImage(img,130,0,w/2,h/2,this);
                 break;
         case 4: g.drawImage(img,130,0,w*2,h*2,this);
                 break;
      }   
    }

}


