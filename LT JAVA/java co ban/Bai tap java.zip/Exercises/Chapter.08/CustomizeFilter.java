import java.awt.*;
import java.awt.image.*;


public class CustomizeFilter extends RGBImageFilter{
     int imageWidth;

     public CustomizeFilter(int imageWidth){
           this.imageWidth=imageWidth;
     }

     public int filterRGB(int x, int y, int rgb){

         int alpha= (rgb & 0xff000000);
         
         if (x<(imageWidth %2)) {
            rgb=  alpha + (rgb & 0x00ffffff) ^ 0xffffff; 
         }else{
            int red=(rgb & 0xff0000) >>16;
            int green=(rgb & 0x00ff00) >>8;
            int blue=(rgb & 0x0000ff);
            int grayLevel=Math.max(red,Math.max(green,blue));
            rgb= (alpha) + (grayLevel <<16)+(grayLevel<<8)+grayLevel;
         }
         return rgb;                    
     }
}




