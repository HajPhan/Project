import java.applet.*;
import java.awt.*;
import java.awt.image.*;

public class CombineImage extends Applet{
 
    Image newImg;
    int pix[] = new int[100* 100];
    
    public void init(){
	Image img1=getImage(getDocumentBase(),"Beans.gif");
	ImageProducer producer=img1.getSource();
	PixelGrabber pg = new PixelGrabber(producer, 0, 0,100, 100, pix, 0, 100);
	try {
		     pg.grabPixels();
	} catch (InterruptedException e) {
	}

       Image img2=getImage(getDocumentBase(),"objects.gif");
       CombineFilter filter=new CombineFilter(pix);
       newImg=createImage(new FilteredImageSource(
                             img2.getSource(), filter));
    }    

    public void paint(Graphics g){
      g.drawImage(newImg,0,0,this);
    }

}

class CombineFilter extends RGBImageFilter{
     int pix[];
     public CombineFilter(int pix[]){
       this.pix=pix;
     }

     public int filterRGB(int x, int y, int rgb){
         
         if ((x<100)&&(y<100)) {
             int r=pix[x+y*100] & 0xff0000; 
             return ((rgb & 0xff00ffff)| r);   
         }       
         return rgb;
     }
}




